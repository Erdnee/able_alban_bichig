import React from 'react';
import "../css/Menu.css"
import MenuItem from "./MenuItem";
function Menu(props) {
  return (
    <div className="menu">
      
      {/**  Logo  **/}
      <table id="logo-table">
        <tbody>
          <tr>
            <td><img src={require("../../img/able.gif")} alt="Able logo"/></td>
          </tr>
          <tr>
            <td><img src={require("../../img/proName.png")} alt="Able logo footer"/></td>
          </tr>
        </tbody>
      </table>
      {/**  Logo ending **/}

      {/** MenuItems **/}
      {/** TODO: store all the informations to dictionary or something  
       *   Generate menuItems by using forEach or Map **/}
      <MenuItem onClick={()=>props.onClick('plan')} name = "Шинэ бичиг төлөвлөлт"/>
      <MenuItem onClick={()=>props.onClick('received')} name = "Ирсэн бичгүүд"/>
      <MenuItem onClick={()=>props.onClick('sent')} name = "Явсан бичгүүд"/>
      <MenuItem onClick={()=>props.onClick('complain')} name = "Өргөдөл, гомдол"/>
      <MenuItem onClick={()=>props.onClick('planNew')} name = "Бичиг төлөвлөлт"/>
      {/** MenuItems ending **/}
    </div>
  );
}

export default Menu;