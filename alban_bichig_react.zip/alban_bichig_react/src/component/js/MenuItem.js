import React from 'react';
import "../css/MenuItem.css";
/*
 * MenuItem class will be useful if there is more than a div to return 
 */
class MenuItem extends React.Component {
    
    // constructor(props){
    //     super(props);
    //     this.state = {
    //         selected = false
    //     }
    // }

    render(){
        return (<div onClick = {this.props.onClick}className="menu-item">{this.props.name}</div>)
    }

}

export default MenuItem;