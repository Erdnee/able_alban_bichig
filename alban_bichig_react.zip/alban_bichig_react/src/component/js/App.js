import React from 'react';
import Menu from "./Menu.js"
import MainBody from "./MainBody.js"

class App extends React.Component {
  
  constructor(){
    super();
    this.state = {
      mainBodyCategory : "plan",
    }
    this.onClick = this.onClick.bind(this)
  }
  onClick(data){
    this.setState(prevState/* prevState will be needed in future I hope*/ => {
      return{
        mainBodyCategory : data,
      }
    });
  }
  render(){
    return (
      <div>
          <Menu onClick={this.onClick}/>
          <MainBody category={this.state.mainBodyCategory}/>
      </div>
    );
  }
}

export default App;
