import React from 'react';
import ComplainData from '../data/ComplainData.js';
class MainBody extends React.Component{
  render(){
    switch(this.props.category){
      case "plan":
        return (
          <div id="main-body" className="plan">
            <h1>plan</h1>
          </div>
        )
      case "received":
        return(
          <h1>received</h1>
        )
      case "sent":
      return(
        <h1>sent</h1>
      )
      case "complain":
        return(
          <div>
            <h1>complain</h1>
          </div>
          
      )
      case "planNew":
        return(
          <h1>planNew</h1>
      )
      default:
        return(<h1>default will be plan</h1>)
    }
    
  }
}

export default MainBody;