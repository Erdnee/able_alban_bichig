const ComplainData = [
    {
        id: 1, //bvrtgeliin dugaar or name it autoNumber
        folderName: "алдаа",// хамаарах бүлэг or name it groupName
        type: 4, //1. Tuluwlusun bichig, 2. irsen bichig, 3. ywsan bichig, 4. urgudul gomdol
        ownDate : 1584241404321,//bichig deerhi ognoo
        receivedDate: 1584241404321,//hvleen awsan ognoo
        date: 1584241404321,//system nemegdsen
        transOption: "Вебээр",   //ilgeesen helber
        roleOption: "Төлөөлж",  //ilgeesen helber
        senderName: "Агентлаг Мэргэжлийн хяналтын байгууллага",//Хаанаас ирсэн
        receivedLink: "", //Хэнд хандсан
        accostDepLink: "", //Хаана хандсан
        ownNumber: "ХН", //Бичгийн дугаар
        pageCnt: 1, //Хуудас тоо
        groupCnt: 1,//ботиин тоо
        receiverInfo: "Хяналтын карт хаагдсан",// Яг одоо хэнд байгаа
        secretOption: "Нууцлалгүй",
        sentDoc: "Өмнөх холбоогүй",
        answerDate: "2020/01/06 даваа гариг",
        category: "Тодорхойгүй"
        //made dummy data to work on
    },

]
export default ComplainData;